import React, { useState } from 'react';
import { useLocation } from 'react-router-dom';
import './style.scss';

export const mbtiData = {
  ISTJ: {
    title: "Na",
    tit_ko: "나트륨",
    alias: "만능 조미료",
    description: "나트륨(Na)은 염소(Cl₂)와 결합해 우리가 일상에서 사용하는 소금을 만들어내는 필수 원소예요.",
    field: "식품",
    info: "나트륨은 소금(NaCl)으로 가장 잘 알려져 있어요.",
    best: "SO₂",
    best_ko: "이산화황",
    best_comment: "나트륨(Na)과 이산화황(SO₂)는 적절한 환경에서 안정적인 결합을 형성해요.",
    worst: "Ne",
    worst_ko: "네온",
    worst_comment: "나트륨(Na)은 반응성이 매우 크지만, 네온(Ne)은 비활성 기체로 반응하지 않아요."
  },
  // 다른 MBTI 유형 데이터 추가 가능
};

type MBTIType = keyof typeof mbtiData;

export const Result = () => {
  const [flipped, setFlipped] = useState(false);
  const location = useLocation();
  const { state } = location;
  const { name } = location.state || {};
  
  const result: MBTIType | '결과가 없습니다.' = state ? state.result : '결과가 없습니다.';

  // MBTI 데이터에서 결과 정보 가져오기
  const mbtiInfo = mbtiData[result as MBTIType];
  if (!mbtiInfo) {
    return <div>해당하는 MBTI 정보가 없습니다.</div>;
  }

  // 필요한 데이터 추출
  const { title, tit_ko, alias, description, field, info, best, best_ko, best_comment, worst, worst_ko, worst_comment } = mbtiInfo;

  // 결과가 title과 같을 때 보여주기
  if (result === title) {
    return (
      <div className='result'>
        <span className='tit'>결과</span>
        <div className='card_cont'>
          <div className={`card ${flipped ? 'flipped' : ''}`} onClick={() => setFlipped(!flipped)}>
            <div className='inner'>
              <div className='front'>
                <span className='card_header'>
                  <img src='img/s_logo.svg' alt='Logo' />
                  <p className='name'>{name ? `${name}님` : '손님'}</p>
                </span>
                <h2 className='type'>{result}</h2>
                <div className='type_box'>{alias}</div>
                <img src={`img/type/${title}.png`} alt={tit_ko} />
                <span className='card_footer'>
                  <div>
                    <img src='img/Icon.svg' alt='Icon' />
                    <p>{title}</p>
                  </div>
                  <p className='tit_ko'>{tit_ko}</p>
                </span>
              </div>
              <div className='back'>
                <p>{description}</p>
                <div>
                  <span>실생활 분야: {field}</span>
                  <span>{info}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className='info'>
          <img src='img/Icon_Arrow.svg' alt='Arrow' />
          <p>카드를 뒤집어 <br /> 자세한 정보를 확인하세요.</p>
        </div>
        <div className='share'>
          <button type='button' onClick={() => navigator.clipboard.writeText(window.location.href).then(() => alert('링크가 복사되었습니다!'))}>
            링크 복사
          </button>
        </div>
        <div className='mixture'>
          <p className='tit'>당신의 조합은?</p>
          <div className='mix_card2'>
            <p className='tit'>안정된 상태</p>
            <div className='name_tag'>
              <span>
                <p className='tit'>{title}</p>
                <span>{tit_ko}</span>
              </span>
              <span>
                <p className='tit'>{best}</p>
                <span>{best_ko}</span>
              </span>
            </div>
          </div>
          <div className='mix_card'>
            <p className='tit'>격렬한 반응</p>
          </div>
        </div>
        <img className='char' src='img/char.png' alt='Character' />
        <div className='cont'>
          <div className='best'>
            <p>나와 잘 맞는 분자는?</p>
            <span>{best}</span>
            <div>
              <p>({title}) vs. ({best})</p>
              {best_comment}
            </div>
          </div>
          <div className='worst'>
            <p>나와 맞지 않는 분자는?</p>
            <span>{worst}</span>
            <div>
              <p>({title}) vs. ({worst})</p>
              {worst_comment}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // 결과가 title과 같지 않을 때의 처리
  return <div>결과가 title과 일치하지 않습니다.</div>;
};
